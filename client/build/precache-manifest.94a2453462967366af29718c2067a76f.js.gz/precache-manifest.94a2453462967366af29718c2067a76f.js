self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "65556c39f70f48038148d560a4ee4cf3",
    "url": "/index.html"
  },
  {
    "revision": "5b023932aa6a682745ef",
    "url": "/static/css/2.8f70debd.chunk.css"
  },
  {
    "revision": "a8772f5b3dfabf2077d1",
    "url": "/static/css/main.2b035f32.chunk.css"
  },
  {
    "revision": "5b023932aa6a682745ef",
    "url": "/static/js/2.188073fd.chunk.js"
  },
  {
    "revision": "2651efb87b2986f15d2e8eb289fe551f",
    "url": "/static/js/2.188073fd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a8772f5b3dfabf2077d1",
    "url": "/static/js/main.d904e821.chunk.js"
  },
  {
    "revision": "46e73bb98ba7986b2555",
    "url": "/static/js/runtime-main.d73a5c01.js"
  },
  {
    "revision": "8688eb2942b9b6e689eed32a1fafcbbd",
    "url": "/static/media/favorite.8688eb29.svg"
  },
  {
    "revision": "307e374382f459b76daeb4860fa16005",
    "url": "/static/media/favorite_border.307e3743.svg"
  }
]);