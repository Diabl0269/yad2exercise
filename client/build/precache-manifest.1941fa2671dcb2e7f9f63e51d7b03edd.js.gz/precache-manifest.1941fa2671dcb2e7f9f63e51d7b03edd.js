self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fab65e72f9576fcb2af5078b7ed9ef3e",
    "url": "/index.html"
  },
  {
    "revision": "08f655f73a123438dac1",
    "url": "/static/css/2.8f70debd.chunk.css"
  },
  {
    "revision": "c87d8d89b90bff49b1f9",
    "url": "/static/css/main.790fcf2a.chunk.css"
  },
  {
    "revision": "08f655f73a123438dac1",
    "url": "/static/js/2.dd09020c.chunk.js"
  },
  {
    "revision": "2651efb87b2986f15d2e8eb289fe551f",
    "url": "/static/js/2.dd09020c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c87d8d89b90bff49b1f9",
    "url": "/static/js/main.321d5f25.chunk.js"
  },
  {
    "revision": "46e73bb98ba7986b2555",
    "url": "/static/js/runtime-main.d73a5c01.js"
  },
  {
    "revision": "8688eb2942b9b6e689eed32a1fafcbbd",
    "url": "/static/media/favorite.8688eb29.svg"
  },
  {
    "revision": "307e374382f459b76daeb4860fa16005",
    "url": "/static/media/favorite_border.307e3743.svg"
  }
]);