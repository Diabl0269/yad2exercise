self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7f0b34bca6eb9eb6e6fd182d732a65fe",
    "url": "/index.html"
  },
  {
    "revision": "b4a1d501c3d2ebf61eb7",
    "url": "/static/css/2.8f70debd.chunk.css"
  },
  {
    "revision": "77478e6f92b789887882",
    "url": "/static/css/main.2b035f32.chunk.css"
  },
  {
    "revision": "b4a1d501c3d2ebf61eb7",
    "url": "/static/js/2.d6616850.chunk.js"
  },
  {
    "revision": "2651efb87b2986f15d2e8eb289fe551f",
    "url": "/static/js/2.d6616850.chunk.js.LICENSE.txt"
  },
  {
    "revision": "77478e6f92b789887882",
    "url": "/static/js/main.f41cc987.chunk.js"
  },
  {
    "revision": "46e73bb98ba7986b2555",
    "url": "/static/js/runtime-main.d73a5c01.js"
  },
  {
    "revision": "8688eb2942b9b6e689eed32a1fafcbbd",
    "url": "/static/media/favorite.8688eb29.svg"
  },
  {
    "revision": "307e374382f459b76daeb4860fa16005",
    "url": "/static/media/favorite_border.307e3743.svg"
  }
]);