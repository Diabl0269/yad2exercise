self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ffe7f05f4671223958c9a5b01a63781d",
    "url": "/index.html"
  },
  {
    "revision": "3c645e766d991e21ff54",
    "url": "/static/css/2.8f70debd.chunk.css"
  },
  {
    "revision": "7f5696b6c727b097d477",
    "url": "/static/css/main.08bd79de.chunk.css"
  },
  {
    "revision": "3c645e766d991e21ff54",
    "url": "/static/js/2.3241ab5d.chunk.js"
  },
  {
    "revision": "2651efb87b2986f15d2e8eb289fe551f",
    "url": "/static/js/2.3241ab5d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7f5696b6c727b097d477",
    "url": "/static/js/main.680bbddd.chunk.js"
  },
  {
    "revision": "46e73bb98ba7986b2555",
    "url": "/static/js/runtime-main.d73a5c01.js"
  },
  {
    "revision": "8688eb2942b9b6e689eed32a1fafcbbd",
    "url": "/static/media/favorite.8688eb29.svg"
  },
  {
    "revision": "307e374382f459b76daeb4860fa16005",
    "url": "/static/media/favorite_border.307e3743.svg"
  }
]);