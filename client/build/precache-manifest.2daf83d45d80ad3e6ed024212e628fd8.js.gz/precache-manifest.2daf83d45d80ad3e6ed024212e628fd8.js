self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cc701f8dcb9105ccdb0bf602e99386a9",
    "url": "/index.html"
  },
  {
    "revision": "94ac47e5101306de4f75",
    "url": "/static/css/2.8f70debd.chunk.css"
  },
  {
    "revision": "98765732f7df4b6136e8",
    "url": "/static/css/main.bfe9ff25.chunk.css"
  },
  {
    "revision": "94ac47e5101306de4f75",
    "url": "/static/js/2.db25df02.chunk.js"
  },
  {
    "revision": "2651efb87b2986f15d2e8eb289fe551f",
    "url": "/static/js/2.db25df02.chunk.js.LICENSE.txt"
  },
  {
    "revision": "98765732f7df4b6136e8",
    "url": "/static/js/main.a559cba2.chunk.js"
  },
  {
    "revision": "46e73bb98ba7986b2555",
    "url": "/static/js/runtime-main.d73a5c01.js"
  },
  {
    "revision": "8688eb2942b9b6e689eed32a1fafcbbd",
    "url": "/static/media/favorite.8688eb29.svg"
  },
  {
    "revision": "307e374382f459b76daeb4860fa16005",
    "url": "/static/media/favorite_border.307e3743.svg"
  }
]);